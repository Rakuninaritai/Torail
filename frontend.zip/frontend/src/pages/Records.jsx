import React from 'react'
import RecordsList from '../components/RecordsList'

const Records = ({token,koushin }) => {
  return (
    <div>
      <RecordsList token={token} key={koushin} />
    </div>
  )
}

export default Records