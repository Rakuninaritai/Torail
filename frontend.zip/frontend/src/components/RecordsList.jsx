import React, { useEffect, useState } from 'react'

const RecordsList = ({token}) => {
  const [records,setRecords]=useState([]);
  // 初回のみ実行
  useEffect(() => {
    // APIを呼び出す
    fetch("http://127.0.0.1:8000/api/records/",{
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      }
    })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json(); // JSONデータを取得
    })
    .then((data) => {
      console.log("Fetched records:", data);
      // 保存済みのstateのみ取得
      const runninged = data.filter(record => record.timer_state===2 );
      setRecords(runninged);  // data は配列のはず
    })
    // エラーが出るとcatchでerrorに格納
    .catch((error)=>console.error("Error fetching records:",error));
  },[]);

  return (<>
    <div>RecordsList</div>
    {records.map((record)=>(
      <div key={record.id}>
        {record.date}:{record.task.name}({record.duration}分)
      </div>
    ))}
    </>
  )
}

export default RecordsList