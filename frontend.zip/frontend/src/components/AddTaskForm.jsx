import React, {  useState } from 'react'

const AddTaskForm = ({token,changes,sub}) => {
  const [formData,setFormData]=useState({
      subject:sub,
      name:"",
  })
  // const [subjects,setSubjects]=useState([])
  const handleChange=(e)=>{
    setFormData({...formData,[e.target.name]:e.target.value})
  }
  // useEffect(()=>{
  //   // subjectsのデータを取得し
  //   fetch("http://127.0.0.1:8000/api/subjects/",{
  //     headers: {
  //       "Content-Type": "application/json",
  //       "Authorization": `Token ${token}`
  //     }
  //   })
  //   // 取得出来たらresとして受け取りjson化
  //   .then((res)=>res.json())
  //   // json化したのをdataとしてsetsubjectsに入れる
  //   .then((data)=>setSubjects(data))
  //   // エラーが起きたらcatchにくる
  //   .catch((err)=>console.error(err))
  // },[])
  // 送信ボタン押されたら
  const handleSubmit=(e)=>{
    // ページがreloadして送信をデフォルトではしようとするがそれをキャンセルしている
    e.preventDefault();
    // postで送る
    fetch("http://127.0.0.1:8000/api/tasks/",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization": `Token ${token}`
      },
      body:JSON.stringify(formData),
    })
    .then((response)=>response.text())
    .then((data)=>{
      console.log("学習記録が追加されました",data)
      // onRecordAdded();//呼び出してる、Appの更新状態用stateを反転させる関数を(appで反転するとリスと再読み込みさせてる)
      changes()
    })
    .catch((error)=>console.log("Error adding record:",error))
}
  return (
    <form onSubmit={handleSubmit}>
      <h2>課題を追加</h2>
     
      <textarea name='name' placeholder='課題' value={formData.name} onChange={handleChange}  />
      <button type='submit'>追加</button>
    </form>
  )
}

export default AddTaskForm