import React from 'react'
//  タイマー削除用コンポーネント
const DeleteTimer = ({token,record,settimerchange}) => {
  // 削除ボタン押下時関数
  const handleDelete=()=>{
     // 確認ダイアログ
    const result=window.confirm("本当に終了してもよいですか。")
    if (result){
      // DELETE リクエストを使って、既存のレコードを削除する
      fetch(`http://127.0.0.1:8000/api/records/${record.id}/`, {
        method: "DELETE",
        headers: {
          "Authorization": `Token ${token}`
        },
      })
        .then(response => {
          if (!response.ok) {
            throw new Error("レコード更新に失敗しました");
          }
          // return response.json();
          console.log("削除完了")
          settimerchange()
        })
        // .then(data => {
        //   console.log("更新完了:", data);
        //   settimerchange()
        // })
        // .catch(error => console.error("更新エラー:", error));
    }
  }
  return (
    <div>
        <button onClick={handleDelete}>タイマー削除</button>
    </div>
  )
}

export default DeleteTimer