

// 秒から分や時間日に変えるコンポネ
const SectoMin = ({time}) => {
  const sec=time
  // 日数(秒を1日の86400秒で割る)
  const days = Math.floor(sec/ 86400);
  // 残り秒数から時間(1日の余りを時間で割る)
  const hours = Math.floor((sec % 86400) / 3600);
  // 残り秒数から分(時間の余りを分で割る)
  const minutes = Math.floor((sec % 3600) / 60);
  // 残り秒数から秒(分になれなかったやつ)
  const seconds = sec % 60;
  return (
    // 0は表示しない
    <div> 
      {days > 0 && <span>{days}日 </span>}
      {hours > 0 && <span>{hours}時間 </span>}
      {minutes > 0 && <span>{minutes}分 </span>}
      <span>{seconds}秒</span>
    </div>
  )
}

export default SectoMin