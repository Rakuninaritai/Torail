import React, { useState } from 'react'

const AddSubjectForm = ({token,changes}) => {
  const [formData,setFormData]=useState({
    name:"",
  })
  const handleChange=(e)=>{
    setFormData({...formData,[e.target.name]:e.target.value})
  }
  // 送信ボタン押されたら
  const handleSubmit=(e)=>{
    // ページがreloadして送信をデフォルトではしようとするがそれをキャンセルしている
    e.preventDefault();
    // postで送る
    fetch("http://127.0.0.1:8000/api/subjects/",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization": `Token ${token}`
      },
      body:JSON.stringify(formData),
    })
    .then((response)=>response.text())
    .then((data)=>{
      console.log("学習記録が追加されました",data)
      // onRecordAdded();//呼び出してる、Appの更新状態用stateを反転させる関数を(appで反転するとリスと再読み込みさせてる)
      changes()
    })
    .catch((error)=>console.log("Error adding record:",error))
  }
  return (
    <form onSubmit={handleSubmit}>
      <h2>教科を追加</h2>
     
      <textarea name='name' placeholder='教科' value={formData.name} onChange={handleChange}  />
      <button type='submit'>追加</button>
    </form>
  )
}

export default AddSubjectForm