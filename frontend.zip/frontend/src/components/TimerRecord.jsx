import React, { useEffect, useState } from 'react'

// タイマー終了後記録を保存するコンポーネント(確定させる?)
const TimerRecord = ({token,record,settimerchange}) => {
  // formdata(送るデータ)のusestate
  const [formData,setFormData]=useState({
    language:"",
    description:"",
  })
  // 選択肢のある奴のusestate
  const [languages,setLanguages]=useState([])
  // データ取得(選択肢の)(第二が[]につきレンダリング時のみ実行)
  useEffect(()=>{
    // 言語
    fetch("http://127.0.0.1:8000/api/languages/",{
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      }
    })
    .then((res)=>res.json())
    .then((data)=>setLanguages(data))
    .catch((err)=>console.error(err))
  },[])
  // 値が変わったら更新する
  const handleChange=(e)=>{
    setFormData({...formData,[e.target.name]:e.target.value})
  }
  // 送信ボタン押されたら
  const handleSubmit=(e)=>{
    // ページがreloadして送信をデフォルトではしようとするがそれをキャンセルしている
    e.preventDefault();
    // 送るデータにformとデータ入力日と終了のstate2を追加する
    const recordData={
      ...formData,
      date:new Date().toISOString(),
      timer_state:2,
    }
    // 更新
    fetch(`http://127.0.0.1:8000/api/records/${record.id}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      },
      body:JSON.stringify(recordData),
    })
    .then((response)=>response.text())
    .then((data)=>{
      console.log("学習記録が追加されました",data)
      settimerchange()
    })
    .catch((error)=>console.log("Error adding record:",error))
  }
  return (
    <div>
      {record.user.username}
      {record.subject.name}
      {record.task.name}
      {record.duration/1000/60/60}時間
      <form onSubmit={handleSubmit}>
        <h2>学習記録を追加</h2>
        
        <label>
          言語:
          <select name='language' value={formData.language} onChange={handleChange} required>
            <option value="">選択してください</option>
            {languages.map((lang)=>(
              <option key={lang.id} value={lang.id}>{lang.name}</option>
            ))}
          </select>
        </label>
          <textarea name='description' placeholder='学習の詳細' value={formData.description} onChange={handleChange}  />
          <button type='submit'>追加</button>
      </form>
    </div>
  )
}

export default TimerRecord