import React, { useEffect, useRef, useState } from 'react'
import TimerRecord from './TimerRecord'
import DeleteTimer from './DeleteTimer'
import SectoMin from './SectoMin'

// タイマーコンポーネント(計測やストップ)
// ユーザーtokenやタイマーのレコードやタイマーの状態が変化したとき用のstateを持つ
const TimerContorl = ({token,records,settimerchange}) => {
  // タイマの動作のstate
  // 実行中のレコードを取り出し
  const record=records[0]
  // 経過時間取り出し(中断していたらその数字、していないなら0)
  const inialElaapsed=record.duration? record.duration:0
  console.log(inialElaapsed)
  const subtr=record.stop_time?new Date(record.stop_time):new Date(record.start_time)
  console.log(subtr)
  // タイマー計測はstateが0なら(今の時刻-starttime or stop_timeが存在していれば今の時刻-stop_time)
  // stateが2ならaddコンポネが出る
  // 中断時は経過時間を保存と、endtimeを保存(言うまでもなく終わっていないが中断から終了された時の為に保存しておく、中断していることは保存してるstateで管理してる)してstateを1に
  // 再開時はstoptimeを今の時刻にしstoptimeとの差分+経過時間をとりstateを0に
  // 終了時は時刻をendtimeに格納しstateを3に経過時間を保存と登録し終えたら2になる
  // 時間用state
  const [time,setTime]=useState()
  // timer_state表示用state
  const [timerState,setTimerState]=useState()
  // btnのラベル用state(今のタイマーの逆)
  const [btnLabelState,setBtnLabelState]=useState()
  // timerid保持用ref(refはコンポーネント再レンダリングでも値保持)
  const timerIdRef=useRef(null)
  useEffect(()=>{
    // 実行中の場合
    record.timer_state===0&&(
      setTimerState("実行中"),
      setBtnLabelState("中断"),
      timerIdRef.current=setInterval(()=>{
        setTime(Math.floor(((new Date() - subtr) / 1000)+(inialElaapsed/1000)))
        document.title=`${record.task.name}:${(Math.floor((((new Date() - subtr) / 1000)+(inialElaapsed/1000))/60))}分${(Math.floor((((new Date() - subtr) / 1000)+(inialElaapsed/1000))%60))}秒`
      },1000)
    )
    // 中断中の場合
    record.timer_state===1&&(
      setTimerState("中断中"),
      setBtnLabelState("再開"),
      setTime(inialElaapsed/1000)
    )
    // 中断中の場合
    record.timer_state===3&&(
      setTimerState("保存中")
    )
  // コンポーネントがアンマウントされるときにタイマーをクリア
  return () => {
    clearInterval(timerIdRef.current);
  };
  },[token,record])
  
  // 中断ボタン押下時関数
  const handleSusupend=()=>{
    const updateData={
      // 今の時間を経過時間として保存
      duration:time*1000,
      // end時間として今の時刻を
      end_time:new Date().toISOString(),
      // timerのstateを中断中とする
      timer_state:1,
    }
     // PATCH リクエストを使って、既存のレコードを更新する
     fetch(`http://127.0.0.1:8000/api/records/${record.id}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      },
      body: JSON.stringify(updateData)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error("レコード更新に失敗しました");
        }
        return response.json();
      })
      .then(data => {
        console.log("更新完了:", data);
        clearInterval(timerIdRef.current);
        settimerchange()
      })
      .catch(error => console.error("更新エラー:", error));
  }


  
  // 再開ボタン押下時関数
  const handleContinue=()=>{
    const updateData={
      // stop時間として今の時刻を
      stop_time:new Date().toISOString(),
      // timerのstateを実行中とする
      timer_state:0,
    }
     // PATCH リクエストを使って、既存のレコードを更新する
     fetch(`http://127.0.0.1:8000/api/records/${record.id}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      },
      body: JSON.stringify(updateData)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error("レコード更新に失敗しました");
        }
        return response.json();
      })
      .then(data => {
        console.log("更新完了:", data);
        settimerchange()
      })
      .catch(error => console.error("更新エラー:", error));
  }
  // btnIF
  const handleClick=()=>{
    if(timerState==="実行中"){
      handleSusupend()
    }
    if(timerState==="中断中"){
      handleContinue()
    }
  }
// 終了ボタン押下時関数
const handleFnish=()=>{
  // 確認ダイアログ
  const result=window.confirm("本当に終了してもよいですか。")
  // ダイアログがtrueなら
  if (result){
    // 中断中なら終了時刻が入っているのでそのままそれ保存(意味ない)で、じゃなければ今の時刻にする
    const endtime=timerState==="中断中"?new Date(record.end_time):new Date().toISOString()
    
    const updateData={
      // 今の時間を経過時間として保存
      duration:time*1000,
      // end時間として上でやった時刻を
      end_time:endtime,
      // timerのstateを保存中とする
      timer_state:3,
    }
    // PATCH リクエストを使って、既存のレコードを更新する
    fetch(`http://127.0.0.1:8000/api/records/${record.id}/`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Token ${token}`
      },
      body: JSON.stringify(updateData)
    })
      .then(response => {
        if (!response.ok) {
          throw new Error("レコード更新に失敗しました");
        }
        return response.json();
      })
      .then(data => {
        console.log("更新完了:", data);
        clearInterval(timerIdRef.current);
        settimerchange()
      })
      .catch(error => console.error("更新エラー:", error));
  }
}

  return (
    <div>
      {record.timer_state===3?(<TimerRecord token={token} record={record} settimerchange={settimerchange}  />):(
        <div>
          {token}<br/>
          {JSON.stringify(record)}
          <br />
          {record.user.username}
          {record.subject.name}
          {record.task.name}
          <SectoMin time={time}/>
          <button onClick={handleClick}>{btnLabelState}</button>
          <button onClick={handleFnish}>終了する</button>
          {timerState}
        </div>
      )}
      <DeleteTimer token={token} record={record} settimerchange={settimerchange}/>
    </div>
  )
}

export default TimerContorl